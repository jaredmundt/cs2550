const object1 = {
  x: 1,
  y: 2
};

console.log(Reflect.get(object1, 'x'));
// expected output: 1

var array1 = ['zero', 'one'];

console.log(Reflect.get(array1, 1));
// expected output: "one"
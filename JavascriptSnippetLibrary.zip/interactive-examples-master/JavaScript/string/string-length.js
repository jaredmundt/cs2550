var str = 'Life, the universe and everything. Answer:';
  
console.log(str + ' ' + str.length);
// expected output: "Life, the universe and everything. Answer: 42"
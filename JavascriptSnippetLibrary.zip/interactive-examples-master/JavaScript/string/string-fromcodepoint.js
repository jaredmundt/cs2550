console.log(String.fromCodePoint(65, 90, 48));
// expected output: "AZ0"
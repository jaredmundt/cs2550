var icons = '☃★♲';

console.log(icons.codePointAt(1));
// expected output: "9733"
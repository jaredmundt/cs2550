const flag1 = new Boolean(true);

console.log(flag1.toString());
// expected output: "true"

const flag2 = new Boolean(1);

console.log(flag2.toString());
// expected output: "true"
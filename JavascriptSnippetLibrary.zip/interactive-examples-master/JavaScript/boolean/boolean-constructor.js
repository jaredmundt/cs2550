const flag = new Boolean();

console.log(flag);
// expected output: Boolean: false
console.log(1 + 2 * 3); // 1 + 6
// expected output: 7

console.log(1 + (2 * 3)); // 1 + 6
// expected output: 7

console.log((1 + 2) * 3); // 3 * 3
// expected output: 9

console.log(1 * 3 + 2 * 3); // 3 + 6
// expected output: 9
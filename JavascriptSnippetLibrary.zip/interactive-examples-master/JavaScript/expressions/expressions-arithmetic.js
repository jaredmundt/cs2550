// Number addition and subtraction
console.log(2 + 3 - 1);
// expected output: 4

// Number multiplication and division
console.log(4 * 3 / 2); // 12 / 2
// expected output: 6

// Number remainder and exponential
console.log(11 % 3 ** 2); // 11 % 9
// expected output: 2
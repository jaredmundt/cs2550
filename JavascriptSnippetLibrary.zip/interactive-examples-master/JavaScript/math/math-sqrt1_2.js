function getRoot1Over2() {
  return Math.SQRT1_2;
}

console.log(getRoot1Over2());
// expected output: 0.7071067811865476
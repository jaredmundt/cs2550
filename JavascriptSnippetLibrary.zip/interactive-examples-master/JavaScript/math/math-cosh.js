console.log(Math.cosh(0));
// expected output: 1

console.log(Math.cosh(1));
// expected output: 1.543080634815244 (approximately)

console.log(Math.cosh(-1));
// expected output: 1.543080634815244 (approximately)

console.log(Math.cosh(2));
// expected output: 3.7621956910836314
console.log(Math.imul(3, 4));
// expected output: 12

console.log(Math.imul(-5, 12));
// expected output: -60

console.log(Math.imul(0xffffffff, 5));
// expected output: -5

console.log(Math.imul(0xfffffffe, 5));
// expected output: -10
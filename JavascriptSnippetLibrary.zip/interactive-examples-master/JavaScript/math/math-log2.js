console.log(Math.log2(3));
// expected output: 1.584962500721156

console.log(Math.log2(2));
// expected output: 1

console.log(Math.log2(1));
// expected output: 0

console.log(Math.log2(0));
// expected output: -Infinity
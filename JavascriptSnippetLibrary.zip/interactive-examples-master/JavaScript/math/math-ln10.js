function getNatLog10() {
  return Math.LN10;
}

console.log(getNatLog10());
// expected output: 2.302585092994046
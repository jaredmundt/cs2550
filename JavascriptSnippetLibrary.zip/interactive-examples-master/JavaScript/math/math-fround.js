console.log(Math.fround(5.5));
// expected output: 5.5

console.log(Math.fround(5.05));
// expected output: 5.050000190734863

console.log(Math.fround(5));
// expected output: 5

console.log(Math.fround(-5.05));
// expected output: -5.050000190734863
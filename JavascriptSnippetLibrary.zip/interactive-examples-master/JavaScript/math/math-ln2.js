function getNatLog2() {
  return Math.LN2;
}

console.log(getNatLog2());
// expected output: 0.6931471805599453
function getRoot2() {
  return Math.SQRT2;
}

console.log(getRoot2());
// expected output: 1.4142135623730951
console.log(Math.cbrt(-1));
// expected output: -1

console.log(Math.cbrt(1));
// expected output: 1

console.log(Math.cbrt(Infinity));
// expected output: Infinity

console.log(Math.cbrt(64));
// expected output: 4
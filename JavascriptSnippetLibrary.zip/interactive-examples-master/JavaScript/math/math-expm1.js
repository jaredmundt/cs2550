console.log(Math.expm1(0));
// expected output: 0

console.log(Math.expm1(1));
// expected output: 1.718281828459045

console.log(Math.expm1(-1));
// expected output: -0.6321205588285577

console.log(Math.expm1(2));
// expected output: 6.38905609893065
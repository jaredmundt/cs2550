console.log(Math.tanh(-1));
// expected output: -0.7615941559557649

console.log(Math.tanh(0));
// expected output: 0

console.log(Math.tanh(Infinity));
// expected output: 1

console.log(Math.tanh(1));
// expected output: 0.7615941559557649
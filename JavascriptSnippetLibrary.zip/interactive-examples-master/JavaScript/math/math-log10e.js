function getLog10e() {
  return Math.LOG10E;
}

console.log(getLog10e());
// expected output: 0.4342944819032518
const birthday = new Date('March 13, 08 04:20');

console.log(birthday.getMinutes());
// expected output: 20
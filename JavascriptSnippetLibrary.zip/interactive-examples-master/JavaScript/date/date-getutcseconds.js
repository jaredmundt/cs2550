const moonLanding = new Date('July 20, 1969, 20:18:04 UTC');

console.log(moonLanding.getUTCSeconds());
// expected output: 4
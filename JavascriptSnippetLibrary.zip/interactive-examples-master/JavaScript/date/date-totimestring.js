const event = new Date('August 19, 1975 23:15:30');

console.log(event.toTimeString());
// expected output: 23:15:30 GMT+0200 (CEST)
// (note: your timezone may vary)